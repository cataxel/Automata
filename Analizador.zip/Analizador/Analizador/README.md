# AnaliLRGram1
analizador sintactico LR de la gramatica 2

Para su ejecucion tiene que hacerce de esta forma:
1. Ubicarse donde se encuentra main.py
2. Usar ``` python3 main.py 'nombre del archivo .ibi a analizar' ```  ( sin las ' ' )

se necesita instalar ademas la libreria PLY usando: ```pip install ply ```
